AutoLinks - Mercado Livre

Como instalar (Chrome):
1) Extraia este zip.
2) Abra chrome://extensions.
3) Ative o Modo do desenvolvedor.
4) Clique em Carregar sem compactacao.
5) Selecione a pasta autolinks-mercado-livre.

Como usar:
1) Abra o painel Autolinks (a extensao tentara abrir Configuracoes ML automaticamente).
2) Clique no icone da extensao.
3) Faça login na extensao com seu e-mail e senha do Autolinks.
4) Depois do login validado, clique em Capturar e enviar cookies.

Observacao:
- A URL do painel fica interna e nao eh editavel pelo cliente.
- A extensao captura apenas cookies de dominios Mercado Livre.
